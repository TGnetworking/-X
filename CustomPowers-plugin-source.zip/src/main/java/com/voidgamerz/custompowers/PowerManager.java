package com.voidgamerz.custompowers;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class PowerManager {

    private final NamespacedKey powerKey;

    public PowerManager(CustomPowers plugin) {
        this.powerKey = new NamespacedKey(plugin, "power_id");
    }

    public NamespacedKey getPowerKey() {
        return powerKey;
    }

    /** Builds the finished, glowing, lore-tagged item for a power. */
    public ItemStack createItem(PowerType type) {
        ItemStack item = new ItemStack(type.getMaterial());
        ItemMeta meta = item.getItemMeta();

        meta.setDisplayName(type.getColor() + "" + ChatColor.BOLD + type.getDisplayName());

        List<String> lore = new ArrayList<>();
        for (String line : type.getLore()) {
            lore.add(ChatColor.GRAY + line);
        }
        lore.add("");
        if (type.isGodPower()) {
            lore.add(ChatColor.YELLOW + "Wear it. Become it.");
        } else if (type.getCooldownSeconds() > 0) {
            lore.add(ChatColor.DARK_GRAY + "Right-click to unleash  |  " + type.getCooldownSeconds() + "s cooldown");
        } else {
            lore.add(ChatColor.DARK_GRAY + "Passive — triggers in combat");
        }
        meta.setLore(lore);

        // Fake-enchant glow without an actual enchant effect
        meta.addEnchant(Enchantment.LUCK, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES);

        meta.getPersistentDataContainer().set(powerKey, PersistentDataType.STRING, type.getId());

        if (type.isGodPower()) {
            // Matches the predicate in the resource pack's models/item/golden_helmet.json
            meta.setCustomModelData(90001);
        }

        item.setItemMeta(meta);
        return item;
    }

    /** Returns which power this item is, or null if it isn't a tagged power item. */
    public PowerType readPower(ItemStack item) {
        if (item == null || item.getType() == Material.AIR || !item.hasItemMeta()) return null;
        ItemMeta meta = item.getItemMeta();
        String id = meta.getPersistentDataContainer().get(powerKey, PersistentDataType.STRING);
        if (id == null) return null;
        return PowerType.fromId(id);
    }
}
