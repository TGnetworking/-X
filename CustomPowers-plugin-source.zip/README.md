# CustomPowers — 15 Powers + Crown of the Void King

A Paper plugin with 15 unique, dangerous relics plus a 16th god-tier power —
the **Crown of the Void King**, a golden helmet.

## ⚠️ One thing to check before you build

Your server is Paper **1.21.11** — that version number doesn't exist in Paper's
own numbering (their versions go 1.21, 1.21.1, 1.21.2 … up to whatever is
newest right now). I've pointed `pom.xml` at `1.21.1-R0.1-SNAPSHOT`, which is
almost certainly what you're actually running. If your server's exact build
differs, open `pom.xml` and change the `<version>` under `paper-api` to match
— check your server console on startup, it prints the exact version.

I could not compile or test this jar myself — this sandbox has no access to
Maven's package repositories, only the plugin source was written here. You'll
need to build it the same way your first CustomWeapons plugin got built.

## Build

```
mvn package
```

The finished jar lands at `target/CustomPowers.jar`.

## Install

1. Copy `CustomPowers.jar` into `E:\MCServer\plugins\`
2. Restart the server
3. Give yourself a power: `/givepower VoidGamerZ_ crown`

## Commands

- `/listpowers` — lists every power's id
- `/givepower <player> <powerId>` — gives that player the item

## The 16 powers

| # | Power | Base item | Type | How it triggers |
|---|-------|-----------|------|------------------|
| 1 | Ember Core | Blaze Powder | Active (12s) | Right-click: ignites + damages everyone within 6 blocks |
| 2 | Drakon's Maw | Dragon's Breath | Active (15s) | Right-click: damage + wither cone in the direction you're facing |
| 3 | Umbral Step | Ender Pearl | Active (10s) | Right-click: teleport behind the nearest enemy, bonus damage |
| 4 | Reaper's Mark | Wither Skeleton Skull | Passive, on-hit | 8% chance per hit to instantly kill the target |
| 5 | Stormcaller | Trident | Passive, on-hit | 20% chance per hit to strike lightning on the target |
| 6 | Glacial Grasp | Blue Ice | Active (14s) | Right-click: freezes + damages the nearest enemy |
| 7 | Gravitum Pull | Eye of Ender | Active (16s) | Right-click: yanks every nearby enemy toward you |
| 8 | Phantom Wings | Phantom Membrane | Active (20s) | Right-click: launches you into a short burst of flight |
| 9 | Crimson Thirst | Redstone | Passive, on-hit | Every hit heals you for 25% of the damage dealt |
| 10 | Seismic Fist | Netherite Ingot | Active (14s) | Right-click: ground slam launches + damages nearby enemies |
| 11 | Venomous Bite | Spider Eye | Passive, on-hit | Every hit applies poison + wither |
| 12 | Mirror Walker | Amethyst Shard | Active (25s) | Right-click: go invisible, spawn 3 glowing decoys |
| 13 | Void Ripple | Gunpowder | Active (16s) | Right-click: AoE knockback + blindness |
| 14 | Berserker's Wrath | Totem of Undying | Passive, low HP | Below 30% HP: burst of Strength + Speed + a small heal (45s internal cooldown) |
| 15 | Soul Shackle | Chain | Active (18s) | Right-click: roots the nearest enemy in place |
| 16 | **Crown of the Void King** | Golden Helmet | **Passive, worn** | While worn: Fire Resistance, Regeneration, Resistance, Speed — and every 30s unleashes **Royal Decree**, an AoE fire+poison+knockback burst around the wearer |

All 16 are tagged items (not recipes) — the only way to get one right now is
`/givepower`. If you want some of them craftable or found in loot chests
instead, tell me and I'll wire that up.

## Resource pack

A separate `powers_resourcepack.zip` gives the Crown its own golden-crown
inventory icon instead of the plain vanilla golden helmet look. To use it:

- **Client-side (simplest):** unzip into `.minecraft/resourcepacks/` and
  enable it from the in-game resource pack menu.
- **Server-side (everyone sees it automatically):** host the zip somewhere
  with a direct download link (e.g. a GitHub release) and set
  `resource-pack=<url>` and `resource-pack-sha1=<hash>` in `server.properties`.

Note: this only re-skins the **item icon** (what you see in your hand and
inventory). Changing how the crown looks *on your head* while worn needs a
separate armor-layer texture, which is a bigger job — say the word if you
want that built next.
